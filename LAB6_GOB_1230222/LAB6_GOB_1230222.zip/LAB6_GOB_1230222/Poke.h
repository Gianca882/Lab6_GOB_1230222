#pragma once
#include <string>
#include <string.h>
#include "Header.h"


class Poke {

private:
	int num;
	std::string nombre;
	int gen;

};