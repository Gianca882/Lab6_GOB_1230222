#pragma once

#include <string>
#include <string.h>
class Poke
{
public:
	int num;
	std::string nombre;
	int gen;
};



